exports.heapsorting = function(arr,order){
    let order_of_sort = order == 1 ? 1 : 0; //default to ascending order
    if(order_of_sort == 0){
        let sorted_arr = [];
        // record start time of algorithm
        let hrstart = process.hrtime();
        initial_min_heap = min_heapify(arr);
        while(initial_min_heap != undefined){
            sorted_arr.push(delete_min(initial_min_heap));
            initial_min_heap = min_heapify(initial_min_heap);
        }
        let hrend = process.hrtime(hrstart);
        let heapsort_data = {};
        heapsort_data.executionTime = 'Execution time: ' + hrend[0] + ' s ' + hrend[1] / 1000000 + ' ms';
        heapsort_data.rawTime = hrend[0]*1000 + hrend[1] / 1000000;
        heapsort_data.sortedData = sorted_arr;
        return heapsort_data;
    }
    else{
        let sorted_arr = [];
        // record start time of algorithm
        let hrstart = process.hrtime();
        initial_max_heap = max_heapify(arr);
        while(initial_max_heap != undefined){
            sorted_arr.push(delete_max(initial_max_heap));
            initial_max_heap = max_heapify(initial_max_heap);
        }
        let hrend = process.hrtime(hrstart);
        let heapsort_data = {};
        heapsort_data.executionTime = 'Execution time: ' + hrend[0] + ' s ' + hrend[1] / 1000000 + ' ms';
        heapsort_data.sortedData = sorted_arr;
        heapsort_data.rawTime = hrend[0]*1000 + hrend[1] / 1000000;
        return heapsort_data;
    }
    
}

function min_heapify(arr){
    if(arr.length != 0){
        let min_arr = [arr[0]];
        i = 1;
        temp = 0;
        while( i < arr.length){
            min_arr.push(arr[i]);
            conflict_flag = true;
            while(conflict_flag){
                for(let j = 0; j <= Math.ceil(Math.log2(min_arr.length + 1)); j++){
                    conflict_flag = false;
                    if(min_arr[2*j+1] < min_arr[j]){
                        temp = min_arr[j];
                        min_arr[j] = min_arr[2*j+1];
                        min_arr[2*j+1] = temp;
                        conflict_flag = true;
                    }
                    if(min_arr[2*j+2] < min_arr[j]){
                        temp = min_arr[j];
                        min_arr[j] = min_arr[2*j+2];
                        min_arr[2*j+2] = temp;
                        conflict_flag = true
                    }
                }
            }
            i++;
        }
        return min_arr;
    }
}

function delete_min(min_heap){
    min_value = min_heap.shift();
    return min_value;
}

function max_heapify(arr){
    if(arr.length != 0){
        let max_arr = [arr[0]];
        i = 1;
        temp = 0;
        while( i < arr.length){
            max_arr.push(arr[i]);
            conflict_flag = true;
            while(conflict_flag){
                for(let j = 0; j <= Math.ceil(Math.log2(max_arr.length + 1)); j++){
                    conflict_flag = false;
                    if(max_arr[2*j+1] > max_arr[j]){
                        temp = max_arr[j];
                        max_arr[j] = max_arr[2*j+1];
                        max_arr[2*j+1] = temp;
                        conflict_flag = true;
                    }
                    if(max_arr[2*j+2] > max_arr[j]){
                        temp = max_arr[j];
                        max_arr[j] = max_arr[2*j+2];
                        max_arr[2*j+2] = temp;
                        conflict_flag = true
                    }
                }
            }
            i++;
        }
        return max_arr;
    }
}

function delete_max(max_heap){
    max_value = max_heap.shift();
    return max_value;
}

module.exports