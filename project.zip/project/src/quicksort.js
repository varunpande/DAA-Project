exports.quicksorting = function(arr,order){
    order_of_sorting = order == 1 ? 1 : 0 //default to ascending
    if(order_of_sorting == 0){
        let first_index_ini = 0;
        let last_index_ini = arr.length - 1;
        // record start time of algorithm
        let hrstart = process.hrtime();
        quicksortAscending(arr,first_index_ini,last_index_ini);
        let hrend = process.hrtime(hrstart);
        let mergesort_data = {};
        mergesort_data.executionTime = 'Execution time: ' + hrend[0] + ' s ' + hrend[1] / 1000000 + ' ms';
        mergesort_data.sortedData = arr;
        mergesort_data.rawTime = hrend[0]*1000 + hrend[1] / 1000000;
        return mergesort_data;
    }
    else{
        let first_index_ini = 0;
        let last_index_ini = arr.length - 1;
        // record start time of algorithm
        let hrstart = process.hrtime();
        quicksortDescending(arr,first_index_ini,last_index_ini);
        let hrend = process.hrtime(hrstart);
        let mergesort_data = {};
        mergesort_data.executionTime = 'Execution time: ' + hrend[0] + ' s ' + hrend[1] / 1000000 + ' ms';
        mergesort_data.sortedData = arr;
        mergesort_data.rawTime = hrend[0]*1000 + hrend[1] / 1000000;
        return mergesort_data;
    }
}

function quicksortAscending(arr,first_index,last_index){
    if(first_index >= last_index){
        return ;
    }
    let left = first_index;
    let center = Math.floor((first_index + last_index)/2);
    let right = last_index;
    let median = center;
    if(arr[center] < arr[left] && arr[center] < arr[right]){
        let temp = arr[left];
        arr[left] = arr[center];
        arr[center] = temp;
        if(arr[center] > arr[right]){
            let temp = arr[right];
            arr[right] = arr[center];
            arr[center] = temp; 
        }
    }
    else if(arr[center] > arr[left] && arr[center] > arr[right]){
        let temp = arr[right];
        arr[right] = arr[center];
        arr[center] = temp;
        if(arr[center] < arr[left]){
            let temp = arr[left];
            arr[left] = arr[center];
            arr[center] = temp; 
        }
    }
    else if(arr[left] > arr[right]){
        let temp = arr[right];
        arr[right] = arr[left];
        arr[left] = temp;
    }
    else if(arr[right] < arr[left]){
        let temp = arr[right];
        arr[right] = arr[left];
        arr[left] = temp;
    }
    while(first_index < last_index){
        if(arr[first_index] <= arr[center] && arr[last_index] >= arr[center]){
            last_index--;
            first_index++;
        }
        else if(arr[first_index] > arr[center]){
            if(arr[last_index] < arr[center]){
                let temp = arr[last_index];
                arr[last_index] = arr[first_index];
                arr[first_index] = temp; 
            }
            last_index--;
        }
        else if(arr[last_index] < arr[center]){
            if(arr[first_index] > arr[center]){
                let temp = arr[last_index];
                arr[last_index] = arr[first_index];
                arr[first_index] = temp; 
            }
            first_index++;
        }
    }
    if(arr[center] > arr[center + 1]){
        let  temp = arr[center];
        arr[center] = arr[center + 1];
        arr[center + 1] = temp;
        median = center + 1;
    }
    if(arr[center] < arr[center - 1]){
        let  temp = arr[center];
        arr[center] = arr[center - 1];
        arr[center - 1] = temp;
        median = center - 1;
    }
    quicksortAscending(arr,left,median - 1);
    quicksortAscending(arr,median + 1,right);
}

function quicksortDescending(arr,first_index,last_index){
    if(first_index >= last_index){
        return ;
    }
    let left = first_index;
    let center = Math.floor((first_index + last_index)/2);
    let right = last_index;
    let median = center;
    if(arr[center] > arr[left] && arr[center] < arr[right]){
        let temp = arr[left];
        arr[left] = arr[center];
        arr[center] = temp;
        if(arr[center] < arr[right]){
            let temp = arr[right];
            arr[right] = arr[center];
            arr[center] = temp; 
        }
    }
    else if(arr[center] > arr[left] && arr[center] < arr[right]){
        let temp = arr[right];
        arr[right] = arr[center];
        arr[center] = temp;
        if(arr[center] > arr[left]){
            let temp = arr[left];
            arr[left] = arr[center];
            arr[center] = temp; 
        }
    }
    else if(arr[left] < arr[right]){
        let temp = arr[right];
        arr[right] = arr[left];
        arr[left] = temp;
    }
    else if(arr[right] > arr[left]){
        let temp = arr[right];
        arr[right] = arr[left];
        arr[left] = temp;
    }
    while(first_index < last_index){
        if(arr[first_index] >= arr[center] && arr[last_index] <= arr[center]){
            last_index--;
            first_index++;
        }
        else if(arr[first_index] < arr[center]){
            if(arr[last_index] > arr[center]){
                let temp = arr[last_index];
                arr[last_index] = arr[first_index];
                arr[first_index] = temp; 
            }
            last_index--;
        }
        else if(arr[last_index] > arr[center]){
            if(arr[first_index] < arr[center]){
                let temp = arr[last_index];
                arr[last_index] = arr[first_index];
                arr[first_index] = temp; 
            }
            first_index++;
        }
    }
    if(arr[center] < arr[center + 1]){
        let  temp = arr[center];
        arr[center] = arr[center + 1];
        arr[center + 1] = temp;
        median = center + 1;
    }
    if(arr[center] > arr[center - 1]){
        let  temp = arr[center];
        arr[center] = arr[center - 1];
        arr[center - 1] = temp;
        median = center - 1;
    }
    quicksortDescending(arr,left,median - 1);
    quicksortDescending(arr,median + 1,right);
}

module.exports